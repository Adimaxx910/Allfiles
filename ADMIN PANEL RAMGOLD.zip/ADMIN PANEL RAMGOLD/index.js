

$("#loginbutton").click(function(){
    const apiUrl = "https://ramgoldprod.azurewebsites.net/api/Account/Login";
    const email = $('#username').val();  
    const password = $('#password').val();
   console.log("hello");

    if (!email || !password) {
        alert("Please enter both username and password.");
        return;
    }
    const requestData = {
        email: email,
        password: password
    };
   $.ajax({
     
        url: apiUrl,
        method: 'POST',
        data: JSON.stringify(requestData),
        contentType: 'application/json',
       
        success: function(response, status, xhr) {
            console.log('API Response:', response);
            console.log('API Response status:', status);
            if (xhr.status === 200) {
                console.log(response);
                //console.log('Login successful:', response);
                const Token = response.token;
                localStorage.setItem("Token", Token);
                alert("suceess Login")
                window.location.href = "./dashboard.html";
            } else {         
                alert("Login failed. Status Code: " + xhr.status);
                console.error('Login failed. Response:', response);
            }
        },
        error: function(xhr, status, error) {
            if (xhr.status === 401) {            
                alert("Invalid username or password. Status Code: ");
            }
            else if( xhr.status === 400) {
                console.log(JSON.stringify(requestData));
                alert("bad request:: ",xhr);
            }   
            else {
                
                alert("Login failed. Status Code: " );
            }
            console.error('API Request Failed. Status:', status, 'Error:', error);
        }
    });
})
const token = localStorage.getItem("Token");
var Totalusers=0;
$(document).ready(function(){
    const UserApi="https://ramgoldprod.azurewebsites.net/api/Customer"
    $.ajax({
        url:UserApi,
        method:'GET',
        headers: {
            "Authorization": `Bearer ${token}`
        },
        dataType:'json',
        success:function(response){
            console.log(response);
            Totalusers=response.length;
            console.log(Totalusers);
            $('#totalusers').text(Totalusers);
            
            localStorage.setItem('UserDetails', JSON.stringify(response));           
        },
        error:function(xhr,status,error){
            console.error('API Request Failed. Status:', status, 'Error:', error);
        }      
})


    const productApi="https://ramgoldprod.azurewebsites.net/api/Products"
    $.ajax({
        url:productApi,
        method:'GET',
        dataType:'json',
        headers: {
            "Authorization": `Bearer ${token}`
        },
        success:function(response){
            
            Totalproducts=response.length;
            $('#totalproducts').text(Totalproducts);
            
            localStorage.setItem('productDetails', JSON.stringify(response));
            console.log(response);
        },
        error:function(xhr,status,error){
            console.error('API Request Failed. Status:', status, 'Error:', error);
        }
        
    })

    // const OrdersApi="https://localhost:44373/api/Orders"
    // $.ajax({
    //     url:OrdersApi,
    //     method:'GET',
    //     dataType:'json',
    //     success:function(response){
            
    //         Totalorders=response.length;
    //         $('#totalorders').text(Totalorders);
            
    //         localStorage.setItem('orderDetails', JSON.stringify(response));
    //          console.log(response);
    //     },
    //     error:function(xhr,status,error){
    //         console.error('API Request Failed. Status:', status, 'Error:', error);
    //     }
        
    // })

   
})




$(document).ready(function(){

    $("#usersbox").on("click", function() {
        // Redirect to page2.html
        window.location.href = "Users/Users.html";
    });   
    
    $("#productsbox").on("click", function() {
        // Redirect to page2.html
        window.location.href = "products/product.html";
    });   

    $("#ordersbox").on("click", function() {
        // Redirect to page2.html
        window.location.href = "Orders/orders.html";
    });   
    
    $("#paymentsbox").on("click", function() {
        // Redirect to page2.html
        window.location.href = "Payments/payment.html";
    });   
     
  
    $("#home").click(function(){
        window.location.href="./dashboard.html"
    })

    $("#logout").click(function(){
        window.location.href="./index.html"
    })
});



