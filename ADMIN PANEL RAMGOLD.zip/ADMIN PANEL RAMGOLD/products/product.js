
 
  $(document).ready(function(){
    const menuIcon = $('.menu-icon');
    const sidebar = $('.sidebar');
    const closeButton = $('.close-btn');
    const menuItems = $('.menu-item');

    menuIcon.click(function(){
        menuIcon.toggleClass('active');
        sidebar.toggleClass('active');
    });

    closeButton.click(function(){
        menuIcon.removeClass('active');
        sidebar.removeClass('active');
    });

    menuItems.each(function(){
        const submenuToggle = $(this).find('.submenu-toggle');
        submenuToggle.click(function(e){
            e.preventDefault();           // Prevents the default link behavior
            $('.menu-item').not($(this).closest('.menu-item')).removeClass('active');
            $(this).closest('.menu-item').toggleClass('active');
        });
    });
});
$(document).ready(function() {
    $("#home").click(function(){
        window.location.href="../dashboard.html"
    })

    $("#logout").click(function(){
        window.location.href="../index.html"
    })
});


function resetFormInputs() {
    // Reset form inputs to empty values
    $("#productForm")[0].reset();
}


$(document).ready(function() {
    // Show popup when the "Add New Product" button is clicked
    $("#addProductButton").click(function() {
        $("#popupWrapper").fadeIn();
    });
    $("#addProductButton").dblclick(function() {
        resetFormInputs(); 
        $("#popupWrapper").fadeOut();
    });
    $(".x-btn").click(function() {
        resetFormInputs(); 
        $("#popupWrapper").fadeOut();
    });
    // Close popup when the close button is clicked
    $("#discardBtn").click(function() {
        resetFormInputs(); 
        $("#popupWrapper").fadeOut();
    });

 
});

const productDetails=JSON.parse(localStorage.getItem("productDetails"))

//console.log(user);
console.log(productDetails);

PopulateTable(productDetails)

function PopulateTable(data){
  const tableBody = $('#data-table tbody');
   var slno=1;
   data.forEach((item, index) => {
        const row = $('<tr></tr>');
        row.append(`<td>${slno}</td>`);
       
        row.append(`<td>${item.productId}</td>`);
        row.append(`<td>${item.name}</td>`);
        row.append(`<td>${item.productImageUrl} </td>`);
        row.append(`<td>${item.description}</td>`);
       
        row.append(`<td>100 grams</td>`);
        row.append(`<td>${item.price}</td>`);
        row.append(`<td>${item.stockQuantity}</td>`);
        row.append(`<td>${item.price}</td>`);
       
        row.append(`<td>${item.price}</td>`);
        row.append(`<td><button id="editbutton" name="Edit" data-index="${index}">EDIT</button></td>`);
        // Add more table cells (columns) as needed
        // Append the row to the table body
        tableBody.append(row);
        slno++;
    });
}


$(document).ready(function() {
    // Event binding code here
    $('#data-table tbody').on('click', '#editbutton', function() {
        const row = $(this).closest('tr');
        const rowIndex = $(this).data('index');
        PopulateProduct(productDetails, rowIndex);
       
        const productId = $("#productId").val();
        const name = $("#productName").val();
        const price = $("#productPrice").val();
        const description = $("#productDescription").val();
        const productImageUrl = $("#imgurl").val();
        const stockQuantity = $("#stocks").val();
   
        let productData={
            productId:productId,
            name:name,
            price:price,
            description:description,
            productImageUrl:productImageUrl,
            stockQuantity:stockQuantity,  
        }
        $("#saveBtn").click(function()
        {
             console.log( productData);
    
            let updateurl="https://ramgoldprod.azurewebsites.net/api/Products";
            let apiUrlWithId = updateurl + "/" + productId;
            $.ajax({
                url: apiUrlWithId, 
                type: 'PUT', 
                contentType: 'application/json', 
                data: JSON.stringify(productData), 
                success: function(response) {
                   
                    console.log('Product updated successfully:', response);
                    alert("Product updated successfully:")
                    
                    $("#popupWrapper").fadeOut();
                    window.location.href="../dashboard.html"
                },
                error: function(xhr, status, error) {
                  
                    console.error('Error updating product:', error);
                }
            });
        
        });
    
        $("#discardBtn").click(function(){
            let productApi='https://ramgoldprod.azurewebsites.net/api/Products'
            let apiUrlWithId = productApi + "/" + productId;
            
            $.ajax({
                url: apiUrlWithId,
                method: "DELETE",
                data: {
                userId: 'productId'
                },
                success: function(response) {
                    
                    console.log("User deleted successfully!");
                    alert("User deleted successfully!")
                    $("#popupWrapper").fadeOut();
                    window.location.href="../dashboard.html"
                },
                error: function(error) {
                    // Handle error response
                    console.error("Error deleting user: ", error);
                }
            }); 
        })
    });
});




function PopulateProduct(data,rowIndex){
    $("#popupWrapper").fadeIn();
     const slectedproduct=data[rowIndex];
     const form = $('#productForm');
    form.find('#productId').val(slectedproduct.productId);
    form.find('#productName').val(slectedproduct.name);
    form.find('#productPrice').val(slectedproduct.price);
    form.find('#quantity').val(slectedproduct.stockQuantity);
    form.find('#stocks').val(slectedproduct.stockQuantity);
    form.find('#imgurl').val(slectedproduct.productImageUrl);
    form.find('#productDescription').val(slectedproduct.description);
  }