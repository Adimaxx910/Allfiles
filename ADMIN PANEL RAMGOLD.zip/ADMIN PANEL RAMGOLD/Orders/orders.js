$(document).ready(function() {
    $("#home").click(function(){
        window.location.href="../dashboard.html"
    })

    $("#logout").click(function(){
        window.location.href="../index.html"
    })
});


const orderDetails=JSON.parse(localStorage.getItem("orderDetails"));
//console.log(user);
console.log(orderDetails);
PopulateTable(orderDetails)
function PopulateTable(data){
   const tableBody = $('#data-table tbody');
   var slno=1;
   data.forEach((item, index) => {
        const row = $('<tr></tr>');
        row.append(`<td>${slno}</td>`);
        row.append(` <td> <input type="radio" name="selectRow"  ></td>`);
        row.append(`<td>${item.orderID}</td>`);
        row.append(`<td>${item.customerID}</td>`);
        row.append(`<td>${item.orderStatus} </td>`);
        row.append(`<td>${item.totalAmount}</td>`);
       
        row.append(`<td>100 grams</td>`);
        row.append(`<td>${item.price}</td>`);
        row.append(`<td>${item.stockQuantity}</td>`);
    
        tableBody.append(row);
        slno++;
    });
}
$('#data-table tbody').on('change', 'input[type="radio"]', function() {
    $("#editorderbutton").prop('disabled',false);
    const selectedorderId=$(this).closest('tr').find('td:eq(2)').text();   //selcting the third column data td:eq(2) 
    localStorage.setItem("orderId",selectedorderId);
    //console.log(selectedUserId);
});

$('#editorderbutton').on('click' ,function(){
    window.location.href="./orderdetailspage.html"
    $(document).ready(function(){
        console.log("afenivgyidf");
    })
})



$(document).ready(function() {
    const Id=localStorage.getItem("orderId");
   
    let orderapi='https://localhost:44373/api/Orders'
    let apiUrlWithId = orderapi + "/" + Id;
   
    $.ajax({
        url:apiUrlWithId,
        method:'GET',
        dataType:'json',
        success:function(response){         
           orderdetails=response; 
           const tableBody = $('#table tbody');
         const row = $('<tr></tr>');
        
         
          row.append(`<td>${orderdetails.orderID}</td>`);
          row.append(`<td>${orderdetails.customerID}</td>`);
          row.append(`<td>${orderdetails.orderDate} </td>`);
          row.append(`<td>${orderdetails.orderStatus}</td>`);
         
          row.append(`<td>100 grams</td>`);
          row.append(`<td>${orderdetails.totalAmount}</td>`);
          row.append(`<td>${orderdetails.stockQuantity}</td>`);
          row.append(`<td>${orderdetails.price}</td>`);
         
          row.append(`<td>${orderdetails.price}</td>`);
          row.append(`<td>100 grams</td>`);
        
         
          tableBody.append(row);
          console.log(orderdetails);
       
        },
        error:function(xhr,status,error){
            console.error('API Request Failed. Status:', status, 'Error:', error);
        }
        
    })
        

    $("#editBtn").click(function() {
        $("#editPopupWrapper").fadeIn();
    });

   
    $("#closeEditPopup").click(function() {
        $("#editPopupWrapper").fadeOut();
    });

    $("#editUserForm").submit(function(event) {
        // Prevent form submission
        event.preventDefault();

        // Get edited user data from form fields
        var editedFirstName = $("#editFirstName").val();
        // Get other form fields similarly

        // Perform update logic using AJAX or API calls
        // For example:
        // $.ajax({
        //     url: "update_user_api_endpoint",
        //     method: "POST",
        //     data: {
        //         firstName: editedFirstName,
        //         // Send other updated fields here
        //     },
        //     success: function(response) {
        //         // Handle success response
        //         console.log("User updated successfully!");
        //         // Close edit popup
        //         $("#editPopupWrapper").fadeOut();
        //     },
        //     error: function(error) {
        //         // Handle error response
        //         console.error("Error updating user: ", error);
        //     }
        // });
    });

    // Delete button click event
    $("#deleteBtn").click(function() {
        //Perform delete logic using AJAX or API calls
        let UserApi='https://localhost:44373/api/Customer'
        let apiUrlWithId = UserApi + "/" + Id;
        console.log(apiUrlWithId);
        $.ajax({
            url: apiUrlWithId,
            method: "DELETE",
            data: {
           userId: "user_id_to_delete"
            },
            success: function(response) {
                
                console.log("User deleted successfully!");
               window.location.href="../dashboard.html"
            },
            error: function(error) {
                // Handle error response
                console.error("Error deleting user: ", error);
            }
        });
    });
});