$(document).ready(function() {
    $("#home").click(function(){
        window.location.href="../dashboard.html"
    })

    $("#logout").click(function(){
        window.location.href="../index.html"
    })
});
