$(document).ready(function() {
    //promocode page transition
    $("#promocodebutton").click(function(){
        window.location.href="./userpromocode.html"
    })
   
  
    $("#home").click(function(){
        window.location.href="../dashboard.html"
    })

    $("#logout").click(function(){
        window.location.href="../index.html"
    })
});

//<-------         populating table Data from the custoomerApi      --------------->


const UserDetails=JSON.parse(localStorage.getItem("UserDetails"))

//console.log(user);
console.log(UserDetails);

PopulateTable(UserDetails)

function PopulateTable(data){
  const tableBody = $('#data-table tbody');
   var slno=1;
   data.forEach(item => {
        const row = $('<tr></tr>');
        row.append(`<td>${slno}</td>`);
        row.append(` <td> <input type="radio" name="selectRow"  ></td>`);
        row.append(`<td>${item.customerId}</td>`);
        row.append(`<td>${item.firstName}  ${item.lastName}</td>`);
        row.append(`<td>${item.email}</td>`);
        row.append(`<td>${item.phoneNumber}</td>`);
        row.append(`<td>${item.dateModified}</td>`);
        // Add more table cells (columns) as needed

        // Append the row to the table body
        tableBody.append(row);
        slno++;
    });
}
//---------------on selcting a user then only editbutton will be enabled and selected userId is stored

$('#data-table tbody').on('change', 'input[type="radio"]', function() {
    $("#edituserbutton").prop('disabled',false);
    const selectedUserId=$(this).closest('tr').find('td:eq(2)').text();   //selcting the third column data td:eq(2) 
    localStorage.setItem("userId",selectedUserId);
    
    

});

$('#edituserbutton').on('click' ,function(){
    window.location.href="./userdetails.html"
    $(document).ready(function(){
        console.log("afenivgyidf");
    })
})


$(document).ready(function() {
    const Id=localStorage.getItem("userId");
   
    let UserApi='https://ramgoldprod.azurewebsites.net/api/Customer'
    let apiUrlWithId = UserApi + "/" + Id;
   
    $.ajax({
        url:apiUrlWithId,
        method:'GET',
        dataType:'json',
        success:function(response){         
           user=response; 
           
        //    console.log((user));
         
        $('#name').val(user.firstName);
        $('#lname').val(user.lastName);
        $('#email').val(user.email);
        $('#adr1').val(user.address1);
        $('#adr2').val(user.address2);
        $('#number').val(user.phoneNumber);
        $('#state').val(user.state);
        $('#country').val(user.country);
        $('#pincode').val(user.pinCode);
        $('#createdAt').val(user.createdAt);
        $('#b_fname').val(user.b_FirstName);
        $('#b_lname').val(user.b_LastName);
        $('#b_email').val(user.email); // Assuming billing email is the same as main email
        $('#b_adr1').val(user.b_Address1);
        $('#b_adr2').val(user.b_Address2);
        $('#b_number').val(user.b_PhoneNumber); // Assuming billing phone number is available
        $('#b_state').val(user.b_State);
        $('#b_country').val(user.country); // Assuming billing country is the same as main country
        $('#b_pincode').val(user.b_PinCode);
        },
        error:function(xhr,status,error){
            console.error('API Request Failed. Status:', status, 'Error:', error);
        }
        
    })


    $("#editBtn").click(function() {
        $("#editPopupWrapper").fadeIn();
    });

   
    $("#closeEditPopup").click(function() {
        $("#editPopupWrapper").fadeOut();
    });

    $("#editUserForm").submit(function(event) {
        // Prevent form submission
        event.preventDefault();

        // Get edited user data from form fields
        var editedFirstName = $("#editFirstName").val();
        // Get other form fields similarly

        // Perform update logic using AJAX or API calls
        // For example:
        // $.ajax({
        //     url: "update_user_api_endpoint",
        //     method: "POST",
        //     data: {
        //         firstName: editedFirstName,
        //         // Send other updated fields here
        //     },
        //     success: function(response) {
        //         // Handle success response
        //         console.log("User updated successfully!");
        //         // Close edit popup
        //         $("#editPopupWrapper").fadeOut();
        //     },
        //     error: function(error) {
        //         // Handle error response
        //         console.error("Error updating user: ", error);
        //     }
        // });
    });

    // Delete button click event
    $("#deleteBtn").click(function() {
        //Perform delete logic using AJAX or API calls
        let UserApi='https://ramgoldprod.azurewebsites.net/api/Customer'
        let apiUrlWithId = UserApi + "/" + Id;
        console.log(apiUrlWithId);
        $.ajax({
            url: apiUrlWithId,
            method: "DELETE",
            data: {
           userId: "user_id_to_delete"
            },
            success: function(response) {
                
                console.log("User deleted successfully!");
               window.location.href="../dashboard.html"
            },
            error: function(error) {
                // Handle error response
                console.error("Error deleting user: ", error);
            }
        });
    });
});
